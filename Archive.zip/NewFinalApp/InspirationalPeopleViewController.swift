//
//  InspirationalPeopleViewController.swift
//  NewFinalApp
//
//  Created by Apple on 8/12/20.
//  Copyright © 2020 Meghan Jachna. All rights reserved.
//

import UIKit

class InspirationalPeopleViewController: UIViewController {
    @IBOutlet weak var inspoLabel: UILabel!
    
    @IBOutlet weak var inspoText: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func one(_ sender: UIButton) {
    }
    @IBAction func two(_ sender: UIButton) {
    }
    @IBAction func three(_ sender: UIButton) {
    }
    @IBAction func four(_ sender: UIButton) {
    }
    @IBAction func five(_ sender: UIButton) {
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
