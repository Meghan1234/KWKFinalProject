//
//  QuotesViewController.swift
//  NewFinalApp
//
//  Created by Apple on 8/12/20.
//  Copyright © 2020 Meghan Jachna. All rights reserved.
//

import UIKit

class QuotesViewController: UIViewController {
    @IBOutlet weak var quotesLabel: UILabel!
    @IBOutlet weak var quotesOne: UITextView!
    @IBOutlet weak var quotesTwo: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func backButton(_ sender: UIButton) {
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
