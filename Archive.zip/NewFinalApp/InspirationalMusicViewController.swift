//
//  InspirationalMusicViewController.swift
//  NewFinalApp
//
//  Created by Apple on 8/12/20.
//  Copyright © 2020 Meghan Jachna. All rights reserved.
//

import UIKit


class InspirationalMusicViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
//        textView.attributedText = attributedString
//

        // Do any additional setup after loading the view.
    }
    
   
    @IBAction func buttonOne(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=Xn676-fLq7I")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonTwo(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=r_8ydghbGSg")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonThree(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=gt8ZB_SSGgw")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonFour(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=BObdDClyZZc")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonFive(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=1k8craCGpgs")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonSix(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=I0tLN22mMlU&list=PLbgUVze2IbT3bNi7ZiCIc4hrntHjwQ9Yg&index=6")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=O71fetlkCZo")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonEight(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=mk48xRzuNvA")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonNine(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=KxnpFKZowcs")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonTen(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=sZ-SwJjkSyw")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonEleven(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=Ue4Jx1oBviI")! as URL, options: [:], completionHandler: nil)
    }
    
    @IBAction func buttonTwelve(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=QEjgPh4SEmU")! as URL, options: [:], completionHandler: nil)
    }
    

    @IBAction func buttonFourteen(_ sender: Any) {
         UIApplication.shared.open(URL(string:"https://www.youtube.com/watch?v=MWASeaYuHZo")! as URL, options: [:], completionHandler: nil)
    }
    
    
    
    
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


