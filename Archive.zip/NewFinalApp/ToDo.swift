//
//  ToDo.swift
//  NewFinalApp
//
//  Created by Julie Ham on 8/13/20.
//  Copyright © 2020 Meghan Jachna. All rights reserved.
//

import UIKit

class ToDoClass {

    var description = ""

}


